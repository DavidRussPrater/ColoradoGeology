package com.example.prate.coloradogeology;

import org.junit.Test;

import static org.junit.Assert.*;

public class QueryUtilsUnitTests {



    @Test
    public void fetchEarthquakeData() {

    }

}