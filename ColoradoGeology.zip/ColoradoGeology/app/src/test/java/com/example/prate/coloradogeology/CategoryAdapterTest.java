package com.example.prate.coloradogeology;

import android.app.Fragment;
import android.content.Context;

import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import static org.junit.Assert.*;

public class CategoryAdapterTest {

    @Mock
    Context mMockContext;
    Fragment mMockFragment;




    @Rule public MockitoRule mockitoRule = MockitoJUnit.rule();

    @Test
    public void getItem() {

        //Creates an object of the CategoryAdapter with mock context
        //CategoryAdapter objectUnderTest = new CategoryAdapter(mMockContext, mMockFragment);

    }

    @Test
    public void getCount() {


    }

    @Test
    public void getPageTitle() {
    }

    @Test
    public void getItem1() {
    }

    @Test
    public void startUpdate() {
    }

    @Test
    public void instantiateItem() {
    }

    @Test
    public void destroyItem() {
    }

    @Test
    public void setPrimaryItem() {
    }

    @Test
    public void finishUpdate() {
    }

    @Test
    public void isViewFromObject() {
    }

    @Test
    public void saveState() {
    }

    @Test
    public void restoreState() {
    }

    @Test
    public void getItemId() {
    }

    @Test
    public void getCount1() {
    }

    @Test
    public void startUpdate1() {
    }

    @Test
    public void instantiateItem1() {
    }

    @Test
    public void destroyItem1() {
    }

    @Test
    public void setPrimaryItem1() {
    }

    @Test
    public void finishUpdate1() {
    }

    @Test
    public void startUpdate2() {
    }

    @Test
    public void instantiateItem2() {
    }

    @Test
    public void destroyItem2() {
    }

    @Test
    public void setPrimaryItem2() {
    }

    @Test
    public void finishUpdate2() {
    }

    @Test
    public void isViewFromObject1() {
    }

    @Test
    public void saveState1() {
    }

    @Test
    public void restoreState1() {
    }

    @Test
    public void getItemPosition() {
    }

    @Test
    public void notifyDataSetChanged() {
    }

    @Test
    public void registerDataSetObserver() {
    }

    @Test
    public void unregisterDataSetObserver() {
    }

    @Test
    public void setViewPagerObserver() {
    }

    @Test
    public void getPageTitle1() {
    }

    @Test
    public void getPageWidth() {
    }
}