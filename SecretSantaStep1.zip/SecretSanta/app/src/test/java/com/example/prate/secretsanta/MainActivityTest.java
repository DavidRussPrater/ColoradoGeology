package com.example.prate.secretsanta;

import org.junit.Test;

import static org.junit.Assert.*;

public class MainActivityTest {

    @Test
    public void createHashMap() {

    }

    @Test
    public void createArrayList() {
    }

    @Test
    public void updateSecretSantaTextView() {
    }
}